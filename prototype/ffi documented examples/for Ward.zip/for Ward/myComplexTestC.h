struct align {
    int finalWt;
    char* finalStr;
};

int testFN(char*, char*, int, int, struct align*);

